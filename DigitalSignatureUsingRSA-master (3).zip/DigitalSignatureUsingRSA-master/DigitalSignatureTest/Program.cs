﻿using DigitalSignatureTest;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Ionic.Zip;
using clsFTPLib;
using System.Threading.Tasks;
using System.Net;

using System.IO.Compression;
using System.Security.Cryptography;

namespace DigitalSignatureTest
{
    class Program
    {
       
        static void Main(string[] args)
        {

            //testzip();
            //  testunzip();
            // mergefile();
            //digitalsignature();
            //bool test = false;

         //   string fileclient = @"..\..\File\fileclient.txt";
         ///   testzip(fileclient);

         //  splitfile(@"..\..\File\fileclient.txt.gz.gz", 5);
           MergeFile(@"..\..\File", @"..\..\Output");

           string fileclient = @"..\..\\Output\fileclient.gz";
           testunzip(fileclient);

        }

        protected static string GetBase64StringForImage(string imgPath)
        {
            byte[] imageBytes = System.IO.File.ReadAllBytes(imgPath);
            string base64String = Convert.ToBase64String(imageBytes);
            return base64String;
        }

        static void digitalsignature()
        {
            string privateKeyPath = @"..\..\Keys\private.pem";
            string publickeyPath = @"..\..\Keys\\public.pem";


            string fileclient = @"..\..\File\fileclient.txt";
            string fileclient2 = @"..\..\File\Capturestep2a.png";
            string fileservertemp = @"fileservertemp.txt";
            string tandatanganclient = @"..\..\File\tandatanganclient.png";
            string tandatanganserver = @"..\..\File\tandatanganserver.png";

            string contentclient = File.ReadAllText(fileclient, Encoding.UTF8);
            // Console.WriteLine(contentclient);


            //string tandatanganclientBase64String = GetBase64StringForImage(tandatanganclient);
            //string tandatanganserverBase64String = GetBase64StringForImage(tandatanganserver);



            //string signature = Signature.Sign(tandatanganclientBase64String, privateKeyPath);

            //if (File.Exists(fileservertemp))
            //{
            //    File.Delete(fileservertemp);
            //}

            //using (StreamWriter fileStr = File.CreateText(fileservertemp))
            //{
            //    fileStr.WriteLine(contentclient);
            //    fileStr.WriteLine("Digital Signature");
            //    fileStr.WriteLine(signature);
            //}

            // CompressStringToFile("new.gz", fileclient2);
            //CompressWithDeflate(fileclient,  @"");
            //string anyString = File.ReadAllText(fileservertemp);

            // Output file is 7,388 bytes.
           // CompressStringToFile("new.gz", anyString);


            byte[] file = File.ReadAllBytes("new.gz");
            byte[] decompressed = Decompress(file);
            Console.WriteLine(file.Length);
            Console.WriteLine(decompressed.Length);


           // var lastLine = File.ReadLines(fileservertemp).Last();
            //This will validate the digital signature by using the public key
            //bool isValid = Signature.Verify(tandatanganserverBase64String, publickeyPath, lastLine);

           // Console.WriteLine(@"Is the signature valid ? : {0}", isValid);



            Console.ReadKey();
        }


        public static void zipFile(FileStream originalFileStream,string filename)
        {
            using (FileStream compressedFileStream = File.Create(filename + ".gz"))
            {
                using (GZipStream compressionStream = new GZipStream(compressedFileStream, CompressionMode.Compress))
                {
                    originalFileStream.CopyTo(compressionStream);
                }
            }



        }

        public static void unzipFile(FileInfo fileToDecompress)

        {

            using (FileStream originalFileStream = fileToDecompress.OpenRead())

            {

                string currentFileName = fileToDecompress.FullName;

                string newFileName = currentFileName.Remove(currentFileName.Length - fileToDecompress.Extension.Length);

                using (FileStream decompressedFileStream = File.Create(newFileName))

                {
                    using (GZipStream decompressionStream = new GZipStream(originalFileStream, CompressionMode.Decompress))
                    {
                        decompressionStream.CopyTo(decompressedFileStream);
                    }
                }
            }

        }

        public static void testzip(string fileclient)
        {
            try

            {
              
                FileInfo fi = new FileInfo(fileclient);
                
                using (FileStream originalFileStream = fi.OpenRead())
                {
                    if ((File.GetAttributes(fi.FullName) & FileAttributes.Hidden) != FileAttributes.Hidden & fi.Extension != ".gz")

                    {
                        zipFile(originalFileStream, fi.FullName + ".gz");
                    }
                }

            }

            catch (Exception Ex)

            {

            }
        }

        public static void testunzip(string fileclient)
        {
            try

            {

                 FileInfo fi = new FileInfo(fileclient);


                unzipFile(fi);
             
                


            }

            catch (Exception Ex)

            {

                //MessageBox.Show(Ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }


        public static void splitfile(string SourceFile, int nNoofFiles)
        {
            bool Split = false;
            string mergeFolder;
            List<string> Packets = new List<string>();

            try
            {
                FileStream fs = new FileStream(SourceFile, FileMode.Open, FileAccess.Read);
                int SizeofEachFile = (int)Math.Ceiling((double)fs.Length / nNoofFiles);

                for (int i = 0; i < nNoofFiles; i++)
                {
                    string baseFileName = Path.GetFileNameWithoutExtension(SourceFile);
                    string Extension = Path.GetExtension(SourceFile);

                    FileStream outputFile = new FileStream(Path.GetDirectoryName(SourceFile) + "\\" + baseFileName + "." +
                        i.ToString().PadLeft(5, Convert.ToChar("0")) + Extension + ".tmp", FileMode.Create, FileAccess.Write);

                    mergeFolder = Path.GetDirectoryName(SourceFile);

                    int bytesRead = 0;
                    byte[] buffer = new byte[SizeofEachFile];

                    if ((bytesRead = fs.Read(buffer, 0, SizeofEachFile)) > 0)
                    {
                        outputFile.Write(buffer, 0, bytesRead);
                        //outp.Write(buffer, 0, BytesRead);

                        string packet = baseFileName + "." + i.ToString().PadLeft(3, Convert.ToChar("0")) + Extension.ToString();
                        Packets.Add(packet);
                    }

                    outputFile.Close();

                }
                fs.Close();
            }
            catch (Exception Ex)
            {
                throw new ArgumentException(Ex.Message);
            }

           // return Split;
        }

                       
        public static void MergeFile(string inputfoldername1,string SaveFileFolder)
        {
            bool Output = false;

            try
            {
                string[] tmpfiles = Directory.GetFiles(inputfoldername1, "*.tmp");

                FileStream outPutFile = null;
                string PrevFileName = "";

                foreach (string tempFile in tmpfiles)
                {
                    string fileName = Path.GetFileNameWithoutExtension(tempFile);
                    string baseFileName = fileName.Substring(0, fileName.IndexOf(Convert.ToChar(".")));
                    string extension = Path.GetExtension(fileName);

                    if (!PrevFileName.Equals(baseFileName))
                    {
                        if (outPutFile != null)
                        {
                            outPutFile.Flush();
                            outPutFile.Close();
                        }
                      //  string SaveFileFolder = @"T:\TNO\Benny\test\";
                        outPutFile = new FileStream(SaveFileFolder + "\\" + baseFileName + extension, FileMode.OpenOrCreate, FileAccess.Write);

                    }

                    int bytesRead = 0;
                    byte[] buffer = new byte[1024];
                    FileStream inputTempFile = new FileStream(tempFile, FileMode.OpenOrCreate, FileAccess.Read);

                    while ((bytesRead = inputTempFile.Read(buffer, 0, 1024)) > 0)
                        outPutFile.Write(buffer, 0, bytesRead);

                    inputTempFile.Close();
                    File.Delete(tempFile);
                    PrevFileName = baseFileName;

                }

                outPutFile.Close();
               // lblSendingResult.Text = "Files have been merged and saved at location C:\\";
            }
            catch
            {

            }

           // return Output;

        }

        public static void CompressStringToFile(string fileName, string value)
        {
            // Part A: write string to temporary file.
            string temp = Path.GetTempFileName();
            File.WriteAllText(temp, value);

            // Part B: read file into byte array buffer.
            byte[] b;
            using (FileStream f = new FileStream(temp, FileMode.Open))
            {
                b = new byte[f.Length];
                f.Read(b, 0, (int)f.Length);
            }

            // Part C: use GZipStream to write compressed bytes to target file.
            using (FileStream f2 = new FileStream(fileName, FileMode.Create))
            using (GZipStream gz = new GZipStream(f2, CompressionMode.Compress, false))
            {
                gz.Write(b, 0, b.Length);
            }
        }


        static byte[] Decompress(byte[] gzip)
        {
            // Create a GZIP stream with decompression mode.
            // ... Then create a buffer and write into while reading from the GZIP stream.
            using (GZipStream stream = new GZipStream(new MemoryStream(gzip),
                CompressionMode.Decompress))
            {
                const int size = 4096;
                byte[] buffer = new byte[size];
                using (MemoryStream memory = new MemoryStream())
                {
                    int count = 0;
                    do
                    {
                        count = stream.Read(buffer, 0, size);
                        if (count > 0)
                        {
                            memory.Write(buffer, 0, count);
                        }
                    }
                    while (count > 0);
                    return memory.ToArray();
                }
            }
        }

        //public static void CompressStringToFile(string fileName, string value)
        //{
        //    // Part A: write string to temporary file.
        //    string temp = Path.GetTempFileName();
        //    File.WriteAllText(temp, value);

        //    // Part B: read file into byte array buffer.
        //    byte[] b;
        //    using (FileStream f = new FileStream(temp, FileMode.Open))
        //    {
        //        b = new byte[f.Length];
        //        f.Read(b, 0, (int)f.Length);
        //    }

        //    // Part C: use GZipStream to write compressed bytes to target file.
        //    using (FileStream f2 = new FileStream(fileName, FileMode.Create))
        //    using (GZipStream gz = new GZipStream(f2, CompressionMode.Compress, false))
        //    {
        //        gz.Write(b, 0, b.Length);
        //    }
        //}
        static void CompressWithDeflate(string inputPath, string outputPath)
        {
            // Read in input file.
            byte[] b = File.ReadAllBytes(inputPath);

            // Write compressed data with DeflateStream.
            using (FileStream f2 = new FileStream(outputPath, FileMode.Create))
            using (DeflateStream deflate = new DeflateStream(f2,
                CompressionMode.Compress, false))
            {
                deflate.Write(b, 0, b.Length);
            }
        }
    
        static void compress(string FileName)
        {
            int intSpliteSize = 1;//10 mb
            string NewFileName = "test.zip";
            //if (File.Exists(FileName))
            //{
            //    //Going To Create Zip File
            //    using (ZipFile zip = new ZipFile())
            //    {
            //        zip.UseZip64WhenSaving = Zip64Option.AsNecessary;
            //        zip.CompressionLevel = Ionic.Zlib.CompressionLevel.Default;
            //        zip.AddFile(FileName);
            //        zip.MaxOutputSegmentSize = 65536;// intSpliteSize  * 1024; //split in 10 mb
            //        zip.Save(NewFileName);//save file at same destination
            //        System.Threading.Thread.Sleep(2000);//wait for release resources.
            //    }



            //}

            if (File.Exists(FileName))
            {
                //Going To Create Zip File
                using (ZipFile zip = new ZipFile())
                {
                    zip.UseZip64WhenSaving = Zip64Option.AsNecessary;
                    zip.CompressionLevel = Ionic.Zlib.CompressionLevel.Default;
                    zip.AddFile(FileName);
                    zip.MaxOutputSegmentSize = 65536;// intSpliteSize  * 1024; //split in 10 mb
                                                     // zip.MaxOutputSegmentSize = intSpliteSize * 1024 * 1024; //split in 10 mb
                    zip.Save(NewFileName);//save file at same destination
                    System.Threading.Thread.Sleep(2000);//wait for release resources.

                }
                //end
                //Going to upload file on FTP server.
                ////check directory exits and if then create Direcorty
                //string FTPPath = "ftp://192.168.18.100";//Set here you FTP Url
                //string FTPUserId = "Administrator";//set here your FTP Userid
                //string FTPPassword = "poc123!@#";//set here you FTP Password
                //bool chkDirectoryExits = false;
                //try
                //{
                //    FtpWebRequest requestChkDirectoryExist = (FtpWebRequest)WebRequest.Create(FTPPath); //cheking directory exist on server
                //    requestChkDirectoryExist.Credentials = new NetworkCredential(FTPUserId, FTPPassword);
                //    requestChkDirectoryExist.Method = WebRequestMethods.Ftp.PrintWorkingDirectory;
                //    using (FtpWebResponse response = (FtpWebResponse)requestChkDirectoryExist.GetResponse())
                //    {
                //        //Direcotry Exists.
                //        chkDirectoryExits = true;
                //    }
                //}
                //catch (WebException ex)//throw exeception if file not exist on ftp url
                //{
                //    if (ex.Response != null)
                //    {
                //        FtpWebResponse response = (FtpWebResponse)ex.Response;
                //        if (response.StatusCode == FtpStatusCode.ActionNotTakenFileUnavailable)
                //        {
                //            // Directory not found. 
                //            try
                //            {
                //                //Create New directory
                //                FtpWebRequest requestCreateDirectory = (FtpWebRequest)WebRequest.Create(FTPPath);
                //                requestCreateDirectory.Credentials = new NetworkCredential(FTPUserId, FTPPassword);
                //                requestCreateDirectory.Method = WebRequestMethods.Ftp.MakeDirectory; //create directory on FTP
                //                using (FtpWebResponse response1 = (FtpWebResponse)requestCreateDirectory.GetResponse())
                //                {
                //                    //New directory create.
                //                    chkDirectoryExits = true;
                //                }
                //            }
                //            catch
                //            {
                //                //directory not created
                //                chkDirectoryExits = false;
                //            }
                //        }
                //    }
                //}
                ////
                //if (chkDirectoryExits == true)
                //{
                //    string[] FilePaths = Directory.GetFiles(Directory.GetParent(NewFileName).Name);
                //    foreach (string strFilePath in FilePaths)
                //    {
                //        //start uploding file on FTP URL
                //        FileInfo objFileInfo = new FileInfo(FileName);
                //        AsynchronousFtpUpLoader.Upload(FTPPath + "/" + strFilePath, FileName, FTPUserId, FTPPassword);//upload file from this code
                //        System.Threading.Thread.Sleep(2000);
                //        //check uploded file size both side. FTP and Local file length
                //        FtpWebRequest requestGetFileSize = (FtpWebRequest)WebRequest.Create(FTPPath + "/" + strFilePath);
                //        requestGetFileSize.Credentials = new NetworkCredential(FTPUserId, FTPPassword);
                //        requestGetFileSize.Method = WebRequestMethods.Ftp.GetFileSize;
                //        try
                //        {
                //            using (FtpWebResponse response = (FtpWebResponse)requestGetFileSize.GetResponse())
                //            {
                //                FileInfo info = new FileInfo(FileName);
                //                if (info.Length == response.ContentLength)
                //                {
                //                    //uploded file size is same
                //                }
                //                else
                //                {
                //                    //uploded file size is not same.
                //                }
                //            }
                //        }
                //        catch
                //        { }
                //        //end
                //    }
                //}
                ////end
            }
        }


        static void mergefile()
        {
         
            try
            {
                var options = new ReadOptions { StatusMessageWriter = System.Console.Out };
                using (ZipFile zip = ZipFile.Read(@"..\..\Output\", options))
                {
                    // This call to ExtractAll() assumes:
                    //   - none of the entries are password-protected.
                    //   - want to extract all entries to current working directory
                    //   - none of the files in the zip already exist in the directory;
                    //     if they do, the method will throw.
                    zip.ExtractAll(@"..\..\Result\");
                }
            }
            catch (Exception)
            {
               
            }
            
        }

        //    foreach (FileInfo file in filePaths)
        //    {
        //        var path = filePaths.FullName;
        //        string zipPath = path + file.Name;
        //        string extractPath = Regex.Replace(path + file.Name, ".zip", "");

            //        ZipFile.ExtractToDirectory(zipPath, extractPath);
            //    }

            //    if (!File.Exists(zipFile))
            //        throw new FileNotFoundException();

            //    if (!Directory.Exists(folderPath))
            //        Directory.CreateDirectory(folderPath);

            //    Shell32.Shell objShell = new Shell32.Shell();
            //    Shell32.Folder destinationFolder = objShell.NameSpace(folderPath);
            //    Shell32.Folder sourceFile = objShell.NameSpace(zipFile);

            //    foreach (var file in sourceFile.Items())
            //    {
            //        destinationFolder.CopyHere(file, 4 | 16);
            //    }
            //}
        }
}